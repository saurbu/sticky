function deletePost(id){
    let nid = "postKey"+id
    let post = document.getElementById(nid)
    console.log("object");
    console.log(post);
    post.innerHTML
}
function addPost(){
    let target_ele = document.getElementById("newPostContent")
    let target_text = target_ele.value
    console.log(target_text);

    let key = Math.floor(Math.random() * 1000001);
    console.log(key);

    let html_temp = `
    <div class="notes-container" id="postKey${key}"> 
        <div class="post">
        <img class="uimg" src="pp.png" alt="">

            <p class="uname">Sauravsharma</p>
            <img class="dlt" src="delete.png" alt="" key="postKey${key}" onclick="deletePost(${key})">
            <div class="notes1">
                <p contenteditable="true" class="input-box">  
                    ${target_text}
                </p>
        </div>
    </div> 
    `
    let existingHTML = document.getElementById("post-container")
    existingHTML.insertAdjacentHTML('afterbegin',html_temp)
    target_ele.value = ""
    // get text
    // create a template 
    // clear text
}