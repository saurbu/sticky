<?php
        $conn = mysqli_connect('localhost', 'root', '', 'login');
        session_start();
        if ($_SERVER['REQUEST_METHOD'] == "POST") {
            $email =  $_POST['email'];
            $password =  $_POST['password'];
        
            if (!empty($email) && !empty($password) && !is_numeric($email)) {
                $query = "SELECT * FROM login3 WHERE email='$email' LIMIT 1";
                $result = mysqli_query($conn, $query);
                if ($result) {
                    if ($result && mysqli_num_rows($result) > 0) {
                        $user_data = mysqli_fetch_assoc($result);
                        if ($user_data['password'] == $password) {
                            echo "<script> alert('Successfully logged in'); window.location.href = 'index.html'; </script>";
                            die;
                        }
                    }
                }
                echo "<script> alert('Wrong email and password')</script>";
            } else {
                echo "<script> alert('Wrong email and password')</script>";
            }
        }
        ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css">
    <title>login</title>
</head>
<body>
    <div class="form">
        <img src="img/stickylogo.png" class="logo">
        

        <form action="login.php" class="forrm" method="post">
            <div class="form-group">
                <input type="email" class="uname" placeholder="email" name="email" >
            </div>
            <div class="form-group">
            <input type="password" class="pwd" name="password" placeholder="password">
            </div>
            <div class="form-btn">
                <a href="index.html"><input type="submit" class="login-btn" value="login" name="login" ></a>
            </div>

            <p>------------------Or------------------</p>
        <p class="signup">don't have an account? <br><a href="register.php">sign up</a> </p> 
    </div>
    <div class="img">
        <img class="img1" src="img/logh.png" class="img1" >
    </div>
</body>
</html>