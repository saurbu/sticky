<?php
        if (isset($_POST["submit"])){
            $username = $_POST["username"];
            $email = $_POST["email"];
            $password = $_POST["password"];
            $passwordRepeat = $_POST["repeat_password"];

            $passwordHash = password_hash($password, PASSWORD_DEFAULT);

            $errors = array();
            if (isset($_POST["login"])){
                $email = $_POST["email"];
                $password = $_POST["password"];
                 require_once "database.php";
                 $sql = "SELECT * FROM login3 WHERE email='$email'"; 
                 $result = mysqli_query($conn, $sql);
                 $user = mysqli_fetch_array($result, MYSQLI_ASSOC);
                 if($user){
                    if (password_verify($password, $user["password"])){
                        header("location: index.html");
                        die();
                    }else{
                        echo "<div class='alert alert-danger'>password does not exist</div>";
                    }
                 }else{
                    echo "<div class='alert alert-danger'>user does not exist</div>";
                 }
                }
        }
            else{
                
                $sql = "INSERT INTO login3 (username, email, password) VALUES (?, ?, ?)";
                $stmt = mysqli_stmt_init($conn);
                $preparesmt = mysqli_stmt_prepare($stmt,$sql);
                if ($preparesmt) {
                    mysqli_stmt_bind_param($stmt,"sss",$username,$email,$password);
                    mysqli_stmt_execute($stmt);
                    echo "<div class='alert alert-success' >You are regesterd successfully.</div>";
                    }else {
                        die("something went wrong");
                    }
                    
            }    
            
        
        ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Signup Page</title>

</head>
<body>
    <div class="form">
    <img src="img/stickylogo.png" class="logo">
        <form action="register.php"  method="post">
            <div class="form-group">
                <input type="text" class="email" name="username" placeholder="username">
            </div>
            <div class="form-group">
                <input type="email" class="email" name="email" placeholder="email">
            </div>
            <div class="form-group">
                <input type="password" name="password" class="pwd" placeholder="password">
            </div>
            <div class="form-group">
                <input type="text" name="repeat_password" class="pwd" placeholder="Repeat password">
            </div>
            <div class="form-group">
                <input type="submit" value="Register" class="login-btn" name="submit">
            </div>
            <p>------------------Or------------------</p>
        <p class="signup">Already have an account? <br><a href="login.php">login</a> </p>
        </form>
    </div>
</body>
</html>